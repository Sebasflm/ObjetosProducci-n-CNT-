package ec.gob.cnt.placetopay.core.business.matchfile;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import ec.gob.cnt.placetopay.client.report.reader.ReportRecord;
import ec.gob.cnt.placetopay.core.repository.IPaymentRepository;

/**
 * Genera un archivo de conciliación en el formato VTA
 */
public class MatchFileGenerateVTA implements IMatchFileGenerate {

    private IPaymentRepository paymentRepository;

    public MatchFileGenerateVTA(IPaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    private static Logger log = Logger.getLogger(MatchFileGenerateVTA.class.getName());

    @Override
    public String process(List<ReportRecord> data, LocalDate date, Long bankId) {
        try {
            StringBuilder sb = new StringBuilder();

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
            DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
            log.info("[+] iniciando generador de archivo de conciliación");
            // header
            sb.append("1").append(date.format(dtf)).append("00000000")
                    .append(String.format("%1$8s", data.size() - 1).replace(" ", "0")).append(bankId).append("\n");
            for (ReportRecord item : data) {

                Optional<String> serviceNumber = paymentRepository.getServiceNumber(item.getReference());

                // se ignora la cabecera
                if (!item.getId().equalsIgnoreCase("id")) {
                    LocalDateTime transactionDate = LocalDateTime.parse(item.getTransactionDate(),
                            DateTimeFormatter.ISO_DATE_TIME);
                    sb
                            .append("2C")
                            .append(String.format("%1$20s", item.getReference()))
                            .append(String
                                    .format("%1$15s",
                                            new BigDecimal(item.getAmount()).multiply(BigDecimal.valueOf(100)))
                                    .replace(" ", "0"))
                            .append(String
                                    .format("%1$9s",
                                            serviceNumber.isPresent() ? serviceNumber.get()
                                                    : "--")
                                    .replace(" ", "0"))
                            .append(transactionDate.format(dtf2))
                            .append(String.format("%1$50s", item.getId()))
                            .append("\n");
                }
            }
            log.info("Result file");
            log.info(sb.toString());
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
