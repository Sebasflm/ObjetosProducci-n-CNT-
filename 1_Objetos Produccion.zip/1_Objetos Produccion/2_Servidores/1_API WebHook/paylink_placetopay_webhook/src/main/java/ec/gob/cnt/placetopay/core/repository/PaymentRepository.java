package ec.gob.cnt.placetopay.core.repository;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.logging.Logger;

import ec.gob.cnt.placetopay.core.db.dao.ConsultasProcesosDAO;
import ec.gob.cnt.placetopay.core.db.dtos.Configuracion;
import ec.gob.cnt.placetopay.core.util.ManejoException;
import ec.gob.cnt.util.db.jpa.Transaccion;
import jakarta.persistence.NoResultException;

/**
 *
 * @author aigarcia
 */
public class PaymentRepository implements IPaymentRepository {

    private static final Logger log = Logger.getLogger("repository");

    private static final String dataSourceName = "paylinkplacetopay-PU";

    private ConsultasProcesosDAO dao;

    public PaymentRepository() {
        this.dao = new ConsultasProcesosDAO();
    }

    /**
     * 
     * @param transactionId
     * @param externalId
     * @param transferNumber
     * @param status
     * @param currency
     * @param paymentDate
     * @throws ParseException
     * @throws ManejoException
     */
    public void actualizaPayment(String transactionId, String externalId, String transferNumber,
            String status, String currency, String paymentDate) throws ParseException, ManejoException {
        Transaccion tx = Transaccion.get(dataSourceName);
        try {
            LocalDateTime datePayment = null;
            // ZonedDateTime.now( ZoneOffset.UTC ).format( DateTimeFormatter.ISO_INSTANT );

            if (paymentDate != null) {
                // datePayment = ZonedDateTime.parse(paymentDate,
                // DateTimeFormatter.ISO_INSTANT).toLocalDateTime();
                // datePayment = ZonedDateTime.parse(paymentDate,
                // DateTimeFormatter.ISO_INSTANT).toLocalDateTime();
                datePayment = LocalDateTime.parse(paymentDate, DateTimeFormatter.ISO_DATE_TIME);
            }
            tx.begin();
            dao.actualizaRegistro(tx, transactionId, externalId, transferNumber, status, currency,
                    datePayment);
            tx.commit();
        } catch (ParseException ep) {
            tx.rollback();
            throw ep;
        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
            throw new ManejoException(e.getLocalizedMessage());
        }
    }

    /**
     * Consulta el estado del registro segun TRANSACTIONID y TRANSFERNUMBER
     *
     * @param transacId
     * @param externalId
     * @return
     */
    public Optional<String> consultarProducto(String transacId, String externalId) {
        Optional<String> productType;
        Transaccion tx = Transaccion.get(dataSourceName);
        tx.open();
        try {
            productType = Optional.ofNullable(dao.consultarProducto(tx, transacId, externalId));
        } catch (NoResultException ex) {
            return Optional.empty();
        } catch (Exception e) {
            throw e;
        } finally {
            tx.close();
        }
        return productType;
    }

    public void insertReport(Integer reportId, String internalId, LocalDateTime requestDate,
            LocalDateTime beginDate, LocalDateTime endDate,
            String status,
            String productType, LocalDateTime responseDate, Long bankId) throws ParseException, ManejoException {
        Transaccion tx = Transaccion.get(dataSourceName);
        try {

            tx.begin();

            log.info("reportId-> " + reportId + " internalId->" + internalId + " requesDate-> " + requestDate
                    + " beginDate-> " + beginDate + " endDate->" + endDate + " status-> " + status + " producttye-> "
                    + productType + " responseDate->" + responseDate + " bankId-> " + bankId);

            dao.insertReport(tx, reportId, internalId, requestDate, beginDate, endDate, status, productType,
                    responseDate, bankId);
            tx.commit();
        } catch (ParseException ep) {
            tx.rollback();
            throw ep;
        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
            throw new ManejoException(e.getLocalizedMessage());
        }
    }

    @Override
    public Optional<String> consultarReportId(String internalReportId) {
        Optional<String> reportId;
        Transaccion tx = Transaccion.get(dataSourceName);
        tx.open();
        try {
            reportId = Optional.ofNullable(dao.consultarReportId(tx, internalReportId));
        } catch (NoResultException ex) {
            return Optional.empty();
        } catch (Exception e) {
            throw e;
        } finally {
            tx.close();
        }
        return reportId;
    }

    @Override
    public void updateReportStatus(String internalReportId, String status) throws ParseException, ManejoException {
        Transaccion tx = Transaccion.get(dataSourceName);
        try {
            tx.begin();
            dao.updateReportStatus(tx, internalReportId, status);
            tx.commit();
        } catch (ParseException ep) {
            tx.rollback();
            throw ep;
        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
            throw new ManejoException(e.getLocalizedMessage());
        }
    }

    @Override
    public Optional<Configuracion> getConfiguration(Long bankId) {
        Optional<Configuracion> reportId;
        Transaccion tx = Transaccion.get(dataSourceName);
        tx.open();
        try {
            reportId = dao.consultarConfiguracion(tx, bankId);
        } catch (NoResultException ex) {
            return Optional.empty();
        } catch (Exception e) {
            throw e;
        } finally {
            tx.close();
        }
        return reportId;
    }

    @Override
    public Optional<LocalDateTime> consultarFechaInicio(String internalReportId) {
        Optional<LocalDateTime> reportId = Optional.empty();
        Transaccion tx = Transaccion.get(dataSourceName);
        tx.open();
        try {
            java.sql.Date dateValue = dao.consultarFechaInicio(tx, internalReportId);
            if (dateValue != null) {
                reportId = Optional.ofNullable(dateValue.toLocalDate().atStartOfDay());
            }
        } catch (NoResultException ex) {
            return Optional.empty();
        } catch (Exception e) {
            throw e;
        } finally {
            tx.close();
        }
        return reportId;
    }

    @Override
    public Optional<String> getServiceNumber(String externalId) {
        Optional<String> reportId = Optional.empty();
        Transaccion tx = Transaccion.get(dataSourceName);
        tx.open();
        try {
            reportId = Optional.ofNullable(dao.getServiceNumber(tx, externalId));
        } catch (NoResultException ex) {
            ex.printStackTrace();
            return Optional.empty();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            tx.close();
        }
        return reportId;
    }

}
