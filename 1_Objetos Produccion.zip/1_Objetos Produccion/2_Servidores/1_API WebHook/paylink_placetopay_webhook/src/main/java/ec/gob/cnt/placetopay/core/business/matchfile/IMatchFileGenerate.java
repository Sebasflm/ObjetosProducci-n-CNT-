package ec.gob.cnt.placetopay.core.business.matchfile;

import java.time.LocalDate;
import java.util.List;

import ec.gob.cnt.placetopay.client.report.reader.ReportRecord;

/**
 * Generador de archivo de conciliación
 */
public interface IMatchFileGenerate {

    public String process(List<ReportRecord> data, LocalDate date, Long bankId);
}
