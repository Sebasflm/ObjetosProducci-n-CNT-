package ec.gob.cnt.placetopay.api;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import ec.gob.cnt.placetopay.api.request.Request;
import ec.gob.cnt.placetopay.api.request.validation.IRequestValidation;
import ec.gob.cnt.placetopay.api.request.validation.PlacetoPayRequestValidation;
import ec.gob.cnt.placetopay.client.PlacetoPayClient;
import ec.gob.cnt.placetopay.client.report.generate.response.PlacetoPayReportResponse;
import ec.gob.cnt.placetopay.client.report.reader.ReportReader;
import ec.gob.cnt.placetopay.client.session.response.PlacetoPayResponse;
import ec.gob.cnt.placetopay.core.business.PlacetoPayNonce;
import ec.gob.cnt.placetopay.core.business.matchfile.IMatchFileGenerate;
import ec.gob.cnt.placetopay.core.business.matchfile.MatchFileGenerateVTA;
import ec.gob.cnt.placetopay.core.business.uploadfile.IUploadFile;
import ec.gob.cnt.placetopay.core.business.uploadfile.UploadSftpFile;
import ec.gob.cnt.placetopay.core.db.dtos.Configuracion;
import ec.gob.cnt.placetopay.core.db.dtos.RptaDatos;
import ec.gob.cnt.placetopay.core.repository.IPaymentRepository;
import ec.gob.cnt.placetopay.core.repository.PaymentRepository;
import ec.gob.cnt.placetopay.core.util.ManejoException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

@Path("v1")
@Produces({ "application/json" })
@Consumes({ "application/json" })
public class Api {
    private static Logger log = Logger.getLogger("placetopay_webhook_api");
    static String CALLBACKURL;
    static Long BANKID;
    private static Map<String, String> API_LOGIN = new HashMap<>();
    private static Map<String, String> API_SECRET_KEY = new HashMap<>();

    private IRequestValidation requestValidation;
    private IPaymentRepository repository;

    private IUploadFile uploadFile;
    private static Map<String, String> formatFileName = new HashMap<>();

    static {
        String API_LOGIN_VAR = (String) System.getenv().get("PLACETOPAY_LOGIN");

        for (String item : API_LOGIN_VAR.split("\\|")) {
            API_LOGIN.put(item.split(":")[0], item.split(":")[1]);
        }

        String API_SECRET_KEY_VAR = (String) System.getenv().get("PLACETOPAY_SECRETKEY");
        for (String item : API_SECRET_KEY_VAR.split("\\|")) {
            API_SECRET_KEY.put(item.split(":")[0], item.split(":")[1]);
        }

        String FORMATS_NAME = (String) System.getenv().get("PLACETOPAY_FORMAT_NAME");
        for (String item : FORMATS_NAME.split("\\|")) {
            formatFileName.put(item.split(":")[0], item.split(":")[1]);
        }

        CALLBACKURL = (String) System.getenv().get("PLACETOPAY_CALLBACKURL");
        BANKID = Long.valueOf((String) System.getenv().get("PLACETOPAY_BANKID"));
    }

    public Api() {
        this.requestValidation = new PlacetoPayRequestValidation(API_SECRET_KEY);
        this.repository = new PaymentRepository();

        Optional<Configuracion> config = repository.getConfiguration(BANKID);
        if (config.isPresent()) {
            Configuracion t = config.get();
            log.info("Configuración cargada -> " + t);
            uploadFile = new UploadSftpFile(t.getFileServerHost(), t.getFileServerUser(), t.getFileServerPassword(),
                    t.getFileServerPort(),
                    t.getFileServerPath());
        } else {
            log.severe("Error al cargar la configuración");
        }

    }

    @GET
    @Path("health")
    public Response ping() {
        return Response.ok("{status:up}").build();
    }

    @POST
    @Path("webhook")
    @Produces({ "application/json" })
    public Response webhook(String pbody) {
        try {
            log.info("Call->" + pbody);
            Gson gson = new Gson();
            Request request = (Request) gson.fromJson(pbody, Request.class);
            if (request != null) {
                Optional<String> productType = this.repository.consultarProducto(request.getRequestId(),
                        request.getReference());
                if (productType.isPresent()) {
                    log.info("Producto-> " + (String) productType.get());
                    if (this.requestValidation.isValid(request, (String) productType.get())) {
                        this.repository.actualizaPayment(request.getRequestId(), request.getReference(), "", "TAKEN",
                                "", (String) null);
                        String seed = LocalDateTime.now().toString();
                        PlacetoPayResponse placetoPayResponse = PlacetoPayClient.get().validateSession(
                                request.getRequestId(), PlacetoPayNonce.generate(9), seed,
                                (String) API_SECRET_KEY.get(productType.get()),
                                (String) API_LOGIN.get(productType.get()));
                        log.info("Respuesta-> " + placetoPayResponse);
                        if (placetoPayResponse.getStatus().getStatus().equalsIgnoreCase("APPROVED")) {
                            this.repository.actualizaPayment(request.getRequestId(),
                                    placetoPayResponse.getRequest().getPayment().getReference(),
                                    placetoPayResponse.getPayment().getInternalReference(),
                                    placetoPayResponse.getStatus().getStatus(),
                                    placetoPayResponse.getRequest().getPayment().getAmount().getCurrency(),
                                    placetoPayResponse.getPayment().getStatus().getDate());
                        } else {
                            this.repository.actualizaPayment(request.getRequestId(),
                                    placetoPayResponse.getRequest().getPayment().getReference(), "",
                                    placetoPayResponse.getStatus().getStatus(),
                                    placetoPayResponse.getRequest().getPayment().getAmount().getCurrency(),
                                    (String) null);
                        }

                        return Response.status(Status.OK).entity(new RptaDatos("OK", "--")).build();
                    } else {
                        return Response.status(Status.BAD_REQUEST)
                                .entity(new RptaDatos("BAD_REQUEST", "Request Inválido")).build();
                    }
                } else {
                    return Response.status(Status.BAD_REQUEST).entity(new RptaDatos("BAD_REQUEST", "Request Inválido"))
                            .build();
                }
            } else {
                return Response.status(Status.BAD_REQUEST).entity(new RptaDatos("BAD_REQUEST", "Request Inválido"))
                        .build();
            }
        } catch (JsonSyntaxException var7) {
            var7.printStackTrace();
            return Response.status(Status.BAD_REQUEST).entity(new RptaDatos("ERROR", "Error:" + var7.getMessage()))
                    .build();
        } catch (Exception var8) {
            var8.printStackTrace();
            return Response.status(Status.INTERNAL_SERVER_ERROR)
                    .entity(new RptaDatos("ERROR", "Error:" + var8.getMessage())).build();
        }
    }

    @GET
    @Path("generatereport/{productType}/{startDate}/{endDate}")
    @Produces({ "application/json" })
    public Response generatereport(@PathParam("productType") String productType,
            @PathParam("startDate") String startDate, @PathParam("endDate") String endDate) {
        log.info("[+] Generate report -> " + productType + "-" + startDate + "/" + endDate);
        DateTimeFormatter dft = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate startLocalDate = LocalDate.parse(startDate, dft);
        LocalDate endLocalDate = LocalDate.parse(endDate, dft);
        LocalDateTime startLocalDateTime = startLocalDate.atTime(LocalTime.of(0, 0, 0));
        LocalDateTime endLocalDateTime = endLocalDate.atTime(LocalTime.of(23, 59, 59));
        String seed = LocalDateTime.now().toString();
        String internalReportId = PlacetoPayNonce.generate(6);
        log.info("InternalreportId generated " + internalReportId);
        PlacetoPayReportResponse placetoPayResponse = PlacetoPayClient.get().generateReport(startLocalDateTime,
                endLocalDateTime, CALLBACKURL + "/" + productType + "/" + internalReportId, PlacetoPayNonce.generate(9),
                seed, (String) API_SECRET_KEY.get(productType), (String) API_LOGIN.get(productType));
        log.info("response -> " + placetoPayResponse);
        log.info(" reportid match -> " + placetoPayResponse.getId() + " -> " + internalReportId);

        try {
            this.repository.insertReport(Integer.valueOf(placetoPayResponse.getId()), internalReportId,
                    LocalDateTime.now(), startLocalDateTime, endLocalDateTime, "P", productType, LocalDateTime.now(),
                    BANKID);
            return Response.ok(placetoPayResponse).build();
        } catch (ParseException var13) {
            var13.printStackTrace();
            return Response.serverError().build();
        } catch (ManejoException var14) {
            var14.printStackTrace();
            return Response.serverError().build();
        }
    }

    @GET
    @Path("callback/{productType}/{reportid}")
    @Produces({ "application/json" })
    public Response callback(@PathParam("productType") String productType, @PathParam("reportid") String reportid) {
        log.info("[+] callback [" + productType + "] ReportId[" + reportid + "]");
        Optional<String> idReport = this.repository.consultarReportId(reportid);
        Optional<LocalDateTime> fechaInicio = this.repository.consultarFechaInicio(reportid);

        if (idReport.isPresent()) {
            String seed = LocalDateTime.now().toString();
            String report = PlacetoPayClient.get().getReport((String) idReport.get(), PlacetoPayNonce.generate(9), seed,
                    (String) API_SECRET_KEY.get(productType), (String) API_LOGIN.get(productType));

            log.info("Reporte->");
            log.info(report);
            LocalDate fecha = LocalDate.now();
            if (fechaInicio.isPresent()) {
                fecha = fechaInicio.get().toLocalDate();
            } else {
                log.severe(
                        "[+] No hay fecha inicio configurada para el reporte, usando fecha actual (" + reportid + ")");
            }

            try (ReportReader reportReader = new ReportReader(report)) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
                IMatchFileGenerate matchFileGenerate = new MatchFileGenerateVTA(repository);
                String vtaFileContent = matchFileGenerate.process(reportReader.read(), fecha, BANKID);
                uploadFile.uploadFile(formatFileName.get(productType).replace("%DAY%", fecha.format(dtf)),
                        vtaFileContent.getBytes());
                repository.updateReportStatus(idReport.get(), "A");
                return Response.ok("{status:ACCEPTED}").build();
            } catch (Exception e) {
                e.printStackTrace();
                return Response.serverError().build();
            }

        } else {
            return Response.status(Status.NOT_FOUND).build();
        }
    }

}