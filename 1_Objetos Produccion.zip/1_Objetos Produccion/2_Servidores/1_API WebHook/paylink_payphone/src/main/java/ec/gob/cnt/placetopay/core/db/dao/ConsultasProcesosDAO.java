/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.gob.cnt.placetopay.core.db.dao;

import java.time.LocalDateTime;
import java.util.Optional;

import ec.gob.cnt.placetopay.core.db.dtos.Configuracion;
import ec.gob.cnt.util.db.jpa.JPA;
import ec.gob.cnt.util.db.jpa.Parametro;
import ec.gob.cnt.util.db.jpa.Transaccion;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author mainca
 */
@Getter
@Setter
public class ConsultasProcesosDAO {

        public ConsultasProcesosDAO() {

        }

        /**
         * Actualiza la transaccion de branchId, PosId, paymentDatem, Money
         *
         * @param trans
         * @param transactionId
         * @param externalId
         * @param transferNumber
         * @param sucurId
         * @param status
         * @param currency
         * @param paymentDate
         */
        public void actualizaRegistro(Transaccion trans, String transactionId, String externalId,
                        String transferNumber,
                        String status, String currency, LocalDateTime paymentDate) {
                JPA.get()
                                .setEm(trans.getEm())
                                .setParam(Parametro.get().agregar(1, transactionId).agregar(2, externalId)
                                                .agregar(3, transferNumber)
                                                .agregar(4, status).agregar(5, currency).agregar(6, paymentDate))
                                .ejecutarNativeQueryUpdate(
                                                "UPDATE TRANSACTION_PAYMENT SET TRANSFERNUMBER=?3, STATUSTRANSACTION=?4, MONEYTYPE=?5, PAYMENTDATE=?6 WHERE TRANSACTIONID=?1 AND EXTERNALID=?2");
        }

        /**
         * Consulta el producto
         *
         * @param trans
         * @param transId
         * @param exterId
         * @return
         */
        public String consultarProducto(Transaccion trans, String transId, String exterId) {
                return (String) String.valueOf((Integer) JPA.get()
                                .setEm(trans.getEm())
                                .setParam(Parametro.get().agregar(1, transId).agregar(2, exterId))
                                .ejecutarNativeQuery(
                                                "SELECT RECHARGETYPE FROM TRANSACTION_PAYMENT WHERE TRANSACTIONID = ?1 AND EXTERNALID = ?2"));
        }

        public void insertReport(Transaccion trans, Integer reportId, String internalId, LocalDateTime requestDate,
                        LocalDateTime beginDate, LocalDateTime endDate,
                        String status,
                        String productType, LocalDateTime responseDate, Long bankId) {
                JPA.get()
                                .setEm(trans.getEm())
                                .setParam(Parametro.get().agregar(1, reportId).agregar(2, requestDate)
                                                .agregar(3, beginDate)
                                                .agregar(4, endDate)
                                                .agregar(5, status)
                                                .agregar(6, productType)
                                                .agregar(7, responseDate)
                                                .agregar(8, bankId)
                                                .agregar(9, internalId))
                                .ejecutarNativeQueryUpdate(
                                                "INSERT INTO transaction_report ( transactionId, requestDate, beginDate, endDate, status, productType, responseDate, bankId, internalid) VALUES( ?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8,?9)");
        }

        /**
         * Consulta el producto
         *
         * @param trans
         * @param transId
         * @param exterId
         * @return
         */
        public String consultarReportId(Transaccion trans, String internalReportId) {
                return (String) String.valueOf((Integer) JPA.get()
                                .setEm(trans.getEm())
                                .setParam(Parametro.get().agregar(1, internalReportId))
                                .ejecutarNativeQuery(
                                                "SELECT transactionId FROM transaction_report WHERE internalid = ?1"));
        }

        public void updateReportStatus(Transaccion trans, String internalReportId, String status) {
                JPA.get()
                                .setEm(trans.getEm())
                                .setParam(Parametro.get().agregar(1, internalReportId).agregar(2, status))
                                .ejecutarNativeQueryUpdate(
                                                "UPDATE transaction_report SET status=?2 WHERE internalid = ?1");
        }

        /**
         * Consulta la configuracion del inegrador
         *
         * @param trans
         * @param transId
         * @param exterId
         * @return
         */
        public Optional<Configuracion> consultarConfiguracion(Transaccion trans, Long bankId) {

                Optional<Configuracion> returnValue = Optional.empty();

                Object value = JPA.get()
                                .setEm(trans.getEm())
                                .setParam(Parametro.get().agregar(1, bankId))
                                .ejecutarNativeQuery(
                                                "select p.paco_repo_tipo, p.paco_sftp_ip, p.paco_sftp_puerto, p.paco_sftp_user, p.paco_sftp_pass,p.paco_directorio from paraconci p where p.banco_id = ?1");
                if (value != null) {
                        Object[] fields = (Object[]) value;
                        returnValue = Optional.of(Configuracion.builder()
                                        .fileServerType((String) fields[0])
                                        .fileServerHost((String) fields[1])
                                        .fileServerPort((Integer) fields[2])
                                        .fileServerUser((String) fields[3])
                                        .fileServerPassword((String) fields[4])
                                        .fileServerPath((String) fields[5])
                                        .build());
                }
                return returnValue;
        }

        /**
         * Consulta el service number
         *
         * @param trans
         * @param transId
         * @param exterId
         * @return
         */
        public String getServiceNumber(Transaccion trans, String externalId) {

                try {
                        return ((String) JPA.get()
                                        .setEm(trans.getEm())
                                        .setParam(Parametro.get().agregar(1, externalId))
                                        .ejecutarNativeQuery(
                                                        "SELECT serviceNumber FROM transaction_payment WHERE externalid = ?1"));
                } catch (Exception e) {

                }
                try {
                        return ((String) JPA.get()
                                        .setEm(trans.getEm())
                                        .setParam(Parametro.get().agregar(1, externalId))
                                        .ejecutarNativeQuery(
                                                        "SELECT serviceNumber FROM transaction_paymentlog WHERE externalid = ?1"));
                } catch (Exception e) {

                }
                return null;
        }

}
