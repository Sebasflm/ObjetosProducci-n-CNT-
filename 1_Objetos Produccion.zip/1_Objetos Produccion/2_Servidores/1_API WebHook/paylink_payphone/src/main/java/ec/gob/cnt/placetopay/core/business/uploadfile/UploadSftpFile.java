package ec.gob.cnt.placetopay.core.business.uploadfile;

import java.io.ByteArrayInputStream;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Carga un archivo a un servidor sftp
 */
@Getter
@Setter
@AllArgsConstructor
public class UploadSftpFile implements IUploadFile {

    private String host;
    private String user;
    private String password;
    private int port;
    private String path;

    @Override
    public void uploadFile(String fileName, byte[] contentFile) {
        try {
            JSch jSch = new JSch();
            Session session = jSch.getSession(user, host, port);
            // username and password will be given via UserInfo interface.
            SimplePasswordInfo passwordInfo = new SimplePasswordInfo(password);
            session.setUserInfo(passwordInfo);
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            // config.put("PubkeyAcceptedKeyTypes", "ssh-rsa");
            session.setConfig(config);
            session.connect();

            Channel channel = session.openChannel("sftp");
            channel.connect();
            ChannelSftp sftpChannel = (ChannelSftp) channel;
            // sftpChannel.cd(path);
            ByteArrayInputStream bis = new ByteArrayInputStream(contentFile);
            sftpChannel.put(bis, path + "/" + fileName, null, ChannelSftp.OVERWRITE);
            bis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
