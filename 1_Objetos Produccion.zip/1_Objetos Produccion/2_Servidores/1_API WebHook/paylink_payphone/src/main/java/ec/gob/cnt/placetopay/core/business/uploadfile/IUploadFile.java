package ec.gob.cnt.placetopay.core.business.uploadfile;

/**
 * Define lo que se debe hacer con un archivo VTA
 */
public interface IUploadFile {

    public void uploadFile(String fileName,byte[] contentFile);

}
