package ec.gob.cnt.placetopay.api.request;

public interface ApiRequest {
    
}
