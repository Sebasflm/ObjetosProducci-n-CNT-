package ec.gob.cnt.placetopay.api.request.validation;

import ec.gob.cnt.placetopay.api.request.ApiRequest;

/**
 * Realiza una validación del request
 */
public interface IRequestValidation {

    public boolean isValid(ApiRequest request, String productType);
    
}
