package ec.gob.cnt.placetopay.core.business.uploadfile;

import com.jcraft.jsch.UserInfo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SimplePasswordInfo implements UserInfo {

    private String password;

    @Override
    public String getPassphrase() {
        System.out.println("get -passphrase");
        return null;
    }

    @Override
    public String getPassword() {
        System.out.println("get -password ");
        return password;
    }

    @Override
    public boolean promptPassword(String message) {
        System.out.println("get -promtpassword: " + message);
        return true;
    }

    @Override
    public boolean promptPassphrase(String message) {
        System.out.println("get -promtpassphrase: " + message);
        return false;
    }

    @Override
    public boolean promptYesNo(String message) {
        System.out.println("get -promtyesno: " + message);
        return false;
    }

    @Override
    public void showMessage(String message) {
        System.out.println("mensaje del simplepasswordinfo:" + message);
    }

}
