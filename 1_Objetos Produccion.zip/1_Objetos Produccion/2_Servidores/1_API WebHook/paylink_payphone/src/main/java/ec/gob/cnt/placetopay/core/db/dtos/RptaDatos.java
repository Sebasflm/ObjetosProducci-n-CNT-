package ec.gob.cnt.placetopay.core.db.dtos;

import java.util.Objects;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author mainca
 */
@Getter
@Setter
@ToString
public class RptaDatos {

    private String status;
    private String internalTransactionReference;

    public RptaDatos() {
    }

    public RptaDatos(String status, String internalTransactionReference) {
        this.status = status;
        this.internalTransactionReference = internalTransactionReference;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.status);
        hash = 97 * hash + Objects.hashCode(this.internalTransactionReference);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RptaDatos other = (RptaDatos) obj;
        if (!Objects.equals(this.status, other.status)) {
            return false;
        }
        return Objects.equals(this.internalTransactionReference, other.internalTransactionReference);
    }

}
