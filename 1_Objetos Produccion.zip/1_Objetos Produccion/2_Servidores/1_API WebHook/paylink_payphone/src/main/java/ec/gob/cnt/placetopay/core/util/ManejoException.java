package ec.gob.cnt.placetopay.core.util;

/**
 *
 * @author mainca
 */
public class ManejoException extends Exception{

        public ManejoException(String ex){
            super(ex);
        }
}
