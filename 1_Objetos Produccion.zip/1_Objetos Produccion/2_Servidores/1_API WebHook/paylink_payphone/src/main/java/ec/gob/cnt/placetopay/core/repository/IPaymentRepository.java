package ec.gob.cnt.placetopay.core.repository;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.Optional;

import ec.gob.cnt.placetopay.core.db.dtos.Configuracion;
import ec.gob.cnt.placetopay.core.util.ManejoException;

/**
 *
 * @author aigarcia
 */
public interface IPaymentRepository {

         /**
         * Carga la configuracion del integrador
         * 
         * @param bankId
         * @return
         */
        public Optional<Configuracion> getConfiguration(Long bankId);

        /**
         * 
         * @param transactionId
         * @param externalId
         * @param transferNumber
         * @param status
         * @param currency
         * @param paymentDate
         * @throws ParseException
         * @throws ManejoException
         */
        public void actualizaPayment(String transactionId, String externalId, String transferNumber,
                        String status, String currency, String paymentDate) throws ParseException, ManejoException;

        /**
         * Consulta el estado del registro segun TRANSACTIONID y TRANSFERNUMBER
         *
         * @param transactionId
         * @param externalId
         * @return
         */
        public Optional<String> consultarProducto(String transactionId, String externalId);

        public void insertReport(Integer reportId, String internalId, LocalDateTime requestDate,
                        LocalDateTime beginDate, LocalDateTime endDate,
                        String status,
                        String productType, LocalDateTime responseDate, Long bankId)
                        throws ParseException, ManejoException;

        public Optional<String> consultarReportId(String reportId);

        public void updateReportStatus(String internalReportid, String status) throws ParseException, ManejoException;


        public Optional<String> getServiceNumber(String externalId);

}