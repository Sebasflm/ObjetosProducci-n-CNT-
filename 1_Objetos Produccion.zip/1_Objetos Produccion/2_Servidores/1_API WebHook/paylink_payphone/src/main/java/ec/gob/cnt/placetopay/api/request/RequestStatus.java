package ec.gob.cnt.placetopay.api.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author mainca
 */
@Getter
@Setter
@ToString
public class RequestStatus {

    private String status;
    private String reason;
    private String message;
    private String date;

    public RequestStatus() {

    }

}
