package ec.gob.cnt.placetopay.api.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author mainca
 */
@Getter
@Setter
@ToString
public class Request implements ApiRequest {

    private RequestStatus status;
    private String requestId;
    private String reference;
    private String signature;

    public Request() {
    }

}
