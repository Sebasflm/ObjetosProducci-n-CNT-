package ec.gob.cnt.placetopay.api;

import java.util.Optional;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import ec.gob.cnt.payphone.client.PayPhoneClient;
import ec.gob.cnt.payphone.client.report.generate.response.PayPhoneRepordRecord;
import ec.gob.cnt.payphone.client.report.generate.response.PayPhoneReportResponse;
import ec.gob.cnt.placetopay.core.business.PlacetoPayNonce;
import ec.gob.cnt.placetopay.core.business.matchfile.IMatchFileGenerate;
import ec.gob.cnt.placetopay.core.business.matchfile.MatchFileGenerateVTA;
import ec.gob.cnt.placetopay.core.business.uploadfile.IUploadFile;
import ec.gob.cnt.placetopay.core.business.uploadfile.UploadSftpFile;
import ec.gob.cnt.placetopay.core.db.dtos.Configuracion;
import ec.gob.cnt.placetopay.core.repository.IPaymentRepository;
import ec.gob.cnt.placetopay.core.repository.PaymentRepository;
import ec.gob.cnt.placetopay.core.util.ManejoException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;

@Path("v1")
@Produces({ "application/json" })
@Consumes({ "application/json" })
public class Api {
    private static Logger log = Logger.getLogger("payphone_api");

    static Long BANKID;

    static Map<String, String> STORE_ID = new HashMap<>();

    static String BEARER;
    // static Map<String, String> API_SECRET_KEY = new HashMap<>();

    private IPaymentRepository repository;

    private IUploadFile uploadFile;
    private static Map<String, String> formatFileName = new HashMap<>();

    static {
        String VAR_STOREID = (String) System.getenv().get("PAYPHONE_STOREID");
        for (String item : VAR_STOREID.split("\\|")) {
            STORE_ID.put(item.split(":")[1], item.split(":")[0]);
        }
        String FORMATS_NAME = (String) System.getenv().get("PAYPHONE_FORMAT_NAME");
        for (String item : FORMATS_NAME.split("\\|")) {
            formatFileName.put(item.split(":")[0], item.split(":")[1]);
        }
        BANKID = Long.valueOf((String) System.getenv().get("PAYPHONE_BANKID"));
        BEARER = (String) System.getenv().get("PAYPHONE_SECRETKEY");
    }

    public Api() {
        // this.requestValidation = new PlacetoPayRequestValidation(API_SECRET_KEY);
        this.repository = new PaymentRepository();

        Optional<Configuracion> config = repository.getConfiguration(BANKID);
        if (config.isPresent()) {
            Configuracion t = config.get();
            log.info("Configuración cargada -> " + t);
            uploadFile = new UploadSftpFile(t.getFileServerHost(), t.getFileServerUser(), t.getFileServerPassword(),
                    t.getFileServerPort(),
                    t.getFileServerPath());
        } else {
            log.severe("Error al cargar la configuración");
        }

    }

    @GET
    @Path("health")
    public Response ping() {
        return Response.ok("{status:up}").build();
    }

    @GET
    @Path("generatereport/{startDate}/{endDate}")
    @Produces({ "application/json" })
    public Response generatereport(
            @PathParam("startDate") String startDate, @PathParam("endDate") String endDate) {
        log.info("[+] Generate report -> " + startDate + "/" + endDate);
        DateTimeFormatter dft = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate startLocalDate = LocalDate.parse(startDate, dft);
        LocalDate endLocalDate = LocalDate.parse(endDate, dft);

        String internalReportId = PlacetoPayNonce.generate(4);
        log.info("InternalreportId generated " + internalReportId);

        PayPhoneReportResponse payPhoneResponse = PayPhoneClient.get()
                .generateReport(
                        BEARER,
                        startLocalDate,
                        endLocalDate);
        // log.info("response -> " + payPhoneResponse);

        try {

            DateTimeFormatter dtfFile = DateTimeFormatter.ofPattern("yyyyMMdd");
            // DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
            this.repository.insertReport(Integer.valueOf(internalReportId),
                    internalReportId,
                    LocalDateTime.now(),
                    startLocalDate.atTime(0, 0),
                    endLocalDate.atTime(23, 59),
                    "A",
                    "0", // todos
                    LocalDateTime.now(),
                    BANKID);
            // procesamos los registros

            Map<String, List<PayPhoneRepordRecord>> mapRecords = new HashMap<>();

            log.info("[+] registros: " + payPhoneResponse.getRecords().length);

            for (PayPhoneRepordRecord record : payPhoneResponse.getRecords()) {
                String productType = STORE_ID.get(record.getStoreId());
                if (productType != null) {
                    if (!mapRecords.containsKey(productType)) {
                        mapRecords.put(productType, new ArrayList<>());
                    }
                    // agregamos a la lista
                    mapRecords.get(productType).add(record);
                } else {
                    log.severe("store id no existe:" + record.getStoreId());
                }
            }
            // ahora genera un archivo por cada tipo de producto

            for (Map.Entry<String, List<PayPhoneRepordRecord>> entry : mapRecords.entrySet()) {
                String productType = entry.getKey();
                log.info("Generando archivo de :" + productType);
                IMatchFileGenerate matchFileGenerate = new MatchFileGenerateVTA(repository);
                String vtaFileContent = matchFileGenerate.process(
                        entry.getValue(),
                        startLocalDate, BANKID);

                uploadFile.uploadFile(formatFileName.get(productType).replace("%DAY%", startLocalDate.format(dtfFile)),
                        vtaFileContent.getBytes());

            }
            return Response.ok("{status:OK}").build();

            // return Response.ok(payPhoneResponse).build();
        } catch (ParseException var13) {
            var13.printStackTrace();
            return Response.serverError().build();
        } catch (ManejoException var14) {
            var14.printStackTrace();
            return Response.serverError().build();
        }
    }

}