package ec.gob.cnt.placetopay;

import  jakarta.ws.rs.ApplicationPath;
import  jakarta.ws.rs.core.Application;

/**
 * Configures JAX-RS for the application.
 * @author aigarcia
 */
@ApplicationPath("webhook")
public class AplicacionRest extends Application {
    
}
