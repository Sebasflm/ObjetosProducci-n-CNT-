package ec.gob.cnt.placetopay.core.db.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class Configuracion {
    private String fileServerType;
    private String fileServerHost;
    private Integer fileServerPort;
    private String fileServerUser;
    private String fileServerPassword;
    private String fileServerPath;
}
