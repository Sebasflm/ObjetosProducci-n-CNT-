package ec.gob.cnt.placetopay.core.business;

import java.security.SecureRandom;

public class PlacetoPayNonce {
    public static String generate(int longitud) {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder(longitud);

        for (int i = 0; i < longitud; i++) {
            int digito = random.nextInt(10); // Genera un número entre 0 y 9
            sb.append(digito);
        }

        return sb.toString();
    }
}
