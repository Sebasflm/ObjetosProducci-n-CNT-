package ec.gob.cnt.placetopay.core.business.matchfile;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import ec.gob.cnt.payphone.client.report.generate.response.PayPhoneRepordRecord;
import ec.gob.cnt.placetopay.core.repository.IPaymentRepository;

/**
 * Genera un archivo de conciliación en el formato VTA
 */
public class MatchFileGenerateVTA implements IMatchFileGenerate {

        private IPaymentRepository paymentRepository;

        public MatchFileGenerateVTA(IPaymentRepository paymentRepository) {
                this.paymentRepository = paymentRepository;
        }

        private static Logger log = Logger.getLogger(MatchFileGenerateVTA.class.getName());

        @Override
        public String process(List<PayPhoneRepordRecord> data, LocalDate date, Long bankId) {
                try {
                        StringBuilder sb = new StringBuilder();

                        DateTimeFormatter dtfRecord = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
                        DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
                        log.info("[+] iniciando generador de archivo de conciliación");
                        // header
                        sb.append("1").append(date.format(dtf)).append("00000000")
                                        .append(String.format("%1$8s", data.size()).replace(" ", "0")).append(bankId)
                                        .append("\n");
                        for (PayPhoneRepordRecord item : data) {
                                Optional<String> serviceNumber = paymentRepository
                                                .getServiceNumber(item.getPurchaseOperationNumber());

                                // 2024-09-25 13:52:18.917000
                                LocalDateTime transactionDate = LocalDateTime.parse(
                                                item.getDateTransaction().getDate().substring(0,
                                                                item.getDateTransaction().getDate().indexOf(".")),
                                                dtfRecord);
                                sb
                                                .append("2C")
                                                .append(String.format("%1$30s", item.getPurchaseOperationNumber()))
                                                .append(String
                                                                .format("%1$15s",
                                                                                new BigDecimal(item.getPurchaseAmount())
                                                                                                .multiply(BigDecimal
                                                                                                                .valueOf(100))
                                                                                                .setScale(0))
                                                                .replace(" ", "0"))
                                                .append(String.format("%1$9s",
                                                                serviceNumber.isPresent()
                                                                                ? serviceNumber.get()
                                                                                : "--")
                                                                .replace(" ", "0"))
                                                .append(transactionDate.format(dtf2))
                                                .append(String.format("%1$50s", item.getIdTransaction()))
                                                .append("\n");
                        }
                        // log.info("Result file");
                        // log.info(sb.toString());
                        return sb.toString();
                } catch (Exception e) {
                        e.printStackTrace();
                }
                return null;
        }

}
