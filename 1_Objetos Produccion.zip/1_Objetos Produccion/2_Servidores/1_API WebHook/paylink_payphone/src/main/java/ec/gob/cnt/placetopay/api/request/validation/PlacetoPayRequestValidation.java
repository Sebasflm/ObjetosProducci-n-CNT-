package ec.gob.cnt.placetopay.api.request.validation;

import java.util.Map;
import java.util.logging.Logger;

import org.apache.commons.codec.digest.DigestUtils;

import ec.gob.cnt.placetopay.api.request.ApiRequest;
import ec.gob.cnt.placetopay.api.request.Request;

public class PlacetoPayRequestValidation implements IRequestValidation {

    private static Logger log = Logger.getLogger("placetopay-request-validation");

    private Map<String, String> secretKey;

    public PlacetoPayRequestValidation(Map<String, String> secretKey) {
        this.secretKey = secretKey;
    }

    @Override
    public boolean isValid(ApiRequest apiRequest, String productType) {

        if (apiRequest instanceof Request) {
            Request request = (Request) apiRequest;
            // Validacion de datos obligatorios
            if (request.getReference() == null || request.getRequestId() == null || request.getSignature() == null) {
                return false;
            }
            // validacion de signature
            String input = request.getRequestId() + request.getStatus().getStatus() + request.getStatus().getDate()
                    + secretKey.get(productType);
            if (!request.getSignature().equalsIgnoreCase(DigestUtils.sha1Hex(input))) {
                log.info("validando con " + secretKey.get(productType));
                log.severe("[+] error de validación de signatue [" + DigestUtils.sha1Hex(input) + "] ["
                        + request.getSignature() + "] [" + input + "]");
                return false;
            }

            return true;
        }
        return false;
    }

}
