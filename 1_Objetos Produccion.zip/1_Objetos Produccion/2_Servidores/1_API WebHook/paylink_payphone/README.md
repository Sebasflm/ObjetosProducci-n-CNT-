# Servicio REST - Place to Pay - Webhook

Servicio donde se recibe la notificación de parte del proveedor cuando una sesión es finalizada.

## Request

    {
    "status": {
        "status": "APPROVED",
        "reason": "00",
        "message": "Transacción aprobada",
        "date": "2019-01-01T12:00:00-05:00"
    },
    "requestId": 1234,
    "reference": "TEST_123424",
    "signature": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s"
    }

### Validación
Para poder validar que sea una url confiable, el sistema deberá validar si el signature enviado es el correcto mediante la siguiente formula SHA-1(requestId + status.status + status.date + secretKey)

Una vez que cumpla con la validación del signature, el proceso deberá realizar la siguiente consulta para validar la sesión.

Post: https://checkout-test.placetopay.ec/api/session/797760

    {

           "auth": {
           "login": "8a7165db5151ec75ad959471d431de17",
           "tranKey": "3bZoh5BJHYEbV+YNSvD/bYHVwazL+bMikP/TVb0LKxk=",
           "nonce": "NDU2NDUzMzM5",
           "seed": "2024-09-30T08:30:00-05:00"
                    }
    }

Response: 

    {
        "requestId": 797760,
        "status": {
            "status": "APPROVED",
            "reason": "00",
            "message": "La petición ha sido aprobada exitosamente",
            "date": "2024-09-30T08:26:20-05:00"
        },
        "request": {
            "locale": "es_EC",
            "payer": {
                "document": "1719225409",
                "documentType": "CI",
                "name": "rolando",
                "surname": "Orozco",
                "email": "rorozco1719@gmail.com",
                "mobile": "+593996060627"
            },
            "payment": {
                "reference": "30092408182901",
                "description": "PAGO Recarga Saldo 6.00",
                "amount": {
                    "taxes": [
                        {
                            "kind": "valueAddedTax",
                            "amount": 0.78,
                            "base": 5.22
                        }
                    ],
                    "currency": "USD",
                    "total": 6
                },
                "allowPartial": false,
                "subscribe": false
            },
            "fields": [
                {
                    "keyword": "_processUrl_",
                    "value": "https://checkout-test.placetopay.ec/spa/session/797760/5391936176c39ff9c100e302e0725bf0",
                    "displayOn": "none"
                },
                {
                    "keyword": "_session_",
                    "value": 797760,
                    "displayOn": "none"
                }
            ],
            "returnUrl": "https://200.107.34.224/cntpagos/extjud/resultextj.php?reference=MzAwOTI0MDgxODI5MDE=",
            "ipAddress": "201.219.1.71",
            "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
            "expiration": "2024-09-30T08:38:29-05:00"
        },
        "payment": [
            {
                "amount": {
                    "to": {
                        "total": 6,
                        "currency": "USD"
                    },
                    "from": {
                        "total": 6,
                        "currency": "USD"
                    },
                    "factor": 1
                },
                "status": {
                    "date": "2024-09-30T08:22:31-05:00",
                    "reason": "00",
                    "status": "APPROVED",
                    "message": "Aprobada"
                },
                "receipt": "019249",
                "refunded": false,
                "franchise": "ID_DN",
                "reference": "30092408182901",
                "issuerName": "DINERS CLUB",
                "authorization": "999999",
                "paymentMethod": "diners",
                "processorFields": [
                    {
                        "value": "0001387853",
                        "keyword": "merchantCode",
                        "displayOn": "none"
                    },
                    {
                        "value": "00990099",
                        "keyword": "terminalNumber",
                        "displayOn": "none"
                    },
                    {
                        "value": {
                            "code": "1",
                            "type": "00",
                            "groupCode": "C",
                            "installments": 1
                        },
                        "keyword": "credit",
                        "displayOn": "none"
                    },
                    {
                        "value": 6,
                        "keyword": "totalAmount",
                        "displayOn": "none"
                    },
                    {
                        "value": 0,
                        "keyword": "interestAmount",
                        "displayOn": "none"
                    },
                    {
                        "value": 6,
                        "keyword": "installmentAmount",
                        "displayOn": "none"
                    },
                    {
                        "value": 0,
                        "keyword": "iceAmount",
                        "displayOn": "none"
                    },
                    {
                        "value": "365454",
                        "keyword": "bin",
                        "displayOn": "none"
                    },
                    {
                        "value": "0228",
                        "keyword": "expiration",
                        "displayOn": "none"
                    },
                    {
                        "value": "https://200.107.34.224/cntpagos/extjud/resultextj.php?reference=MzAwOTI0MDgxODI5MDE=",
                        "keyword": "returnUrl",
                        "displayOn": "none"
                    },
                    {
                        "value": true,
                        "keyword": "onTest",
                        "displayOn": "none"
                    },
                    {
                        "value": "C",
                        "keyword": "cardType",
                        "displayOn": "none"
                    },
                    {
                        "value": "0008",
                        "keyword": "lastDigits",
                        "displayOn": "none"
                    },
                    {
                        "value": "821ec3b03c313641aec8b1981bef18d5",
                        "keyword": "id",
                        "displayOn": "none"
                    },
                    {
                        "value": "00",
                        "keyword": "b24",
                        "displayOn": "none"
                    }
                ],
                "internalReference": 29019249,
                "paymentMethodName": "Diners"
            }
        ],
        "subscription": null
    }

Si es diferente a APPROVED deberá colocar el estado (estatusTransaction) que corresponde y eliminar la transacción en la tabla transaction_payment.

• Previo a la actualizacion de los campos se deberá cambiar a estadoTransaction = TAKEN.

• Se debe actualizar los siguintes campos de la tabla transaction_payment

• OrdererIdentification= payer.document
• OrdererName= payer.name || ‘ ‘ || payer.surname
• branchId= processorFields.value (terminalNumber)
• transferNumber= processorFields.value (merchantCode)
• paymentDate=status.date
• StatusTransaction=status.status