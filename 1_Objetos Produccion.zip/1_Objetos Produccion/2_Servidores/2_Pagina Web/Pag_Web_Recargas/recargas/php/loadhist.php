<?php 
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once('../../dao/VTADao.php');

$orderbyI = $_REQUEST['order']['0']['column'];
$orderI   = $_REQUEST['order']['0']['dir'];
			
$draw    = filter_input(INPUT_POST, 'draw', FILTER_SANITIZE_NUMBER_INT);
$orderby = filter_var($orderbyI, FILTER_SANITIZE_NUMBER_INT);
$order   = filter_var($orderI, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
$offset  = filter_input(INPUT_POST, 'start', FILTER_SANITIZE_NUMBER_INT);
$limit   = filter_input(INPUT_POST, 'length', FILTER_SANITIZE_NUMBER_INT);

$serviceNumber = filter_input(INPUT_POST, 'numserv', FILTER_SANITIZE_NUMBER_INT);
$fchini        = filter_input(INPUT_POST, 'fchini', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
$fchfin        = filter_input(INPUT_POST, 'fchfin', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

$orderby = $orderby + 1;
	
$vtaDao = new VTADao();

$totalsearch  = $vtaDao->fetchAllTot($serviceNumber,$fchini,$fchfin);

$totalrecargas  = $vtaDao->fetchAll($serviceNumber,$orderby,$order,$fchini,$fchfin,$limit,$offset);

if($serviceNumber != '')
{
	$totalRecords    = filter_var($totalsearch[0]['count'], FILTER_SANITIZE_NUMBER_INT);
	$totalRecordsFil = filter_var($totalRecords, FILTER_SANITIZE_NUMBER_INT);
}
else
{
	$totalRecords    = filter_var($totalrecargas, FILTER_SANITIZE_NUMBER_INT);
	$totalRecordsFil = filter_var($totalRecords, FILTER_SANITIZE_NUMBER_INT);
}

$json_data = array(
	"draw"            => intval($draw),   
	"recordsTotal"    => intval($totalRecords),  
	"recordsFiltered" => intval($totalRecordsFil),
	"data"            => $totalrecargas
);
echo json_encode($json_data);
?>