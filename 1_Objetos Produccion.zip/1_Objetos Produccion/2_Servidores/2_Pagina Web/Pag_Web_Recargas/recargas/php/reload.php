<?php

$host  = $_SERVER['HTTP_HOST'];
echo "HOST: ".$host."<br>";
	$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	echo "SELF: ".$_SERVER['PHP_SELF']."<br>";
	echo "DIRNAME: ".dirname($_SERVER['PHP_SELF'])."<br>";
	$extra = 'index.php';
	echo "EXTRA: "."http://$host$uri/$extra"."<br>";
	
	$rawNonce1 = bin2hex(random_bytes(16));
	
	$rawNonce2 = bin2hex(openssl_random_pseudo_bytes(16));
	
	$rawNonce3 = mt_rand();
	
	echo $rawNonce1."<br>";
	echo $rawNonce2."<br>";
	echo $rawNonce3."<br>";
	
	$groupmax = 20;
	
	$groupid = mt_rand(1, $groupmax);
	
	echo $groupid;
	
?>