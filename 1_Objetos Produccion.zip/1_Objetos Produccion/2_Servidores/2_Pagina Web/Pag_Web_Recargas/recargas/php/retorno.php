<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
//Obtener parametros de la URL enviados por PayPhone

if(!isset($_REQUEST['requestId']) || !isset($_REQUEST['reference']) || $_REQUEST['requestId'] == '' || $_REQUEST['reference'] == '')
{
	$urlindex = ReturnIndex();
	header("Location: $urlindex");
}
else
{	
	require_once '../../libs/htmlpurifier/library/HTMLPurifier.auto.php';
	require_once('../servicios/sbopa_param.php');
	require_once('../../dao/VTADao.php');
	
	$vtaDao = new VTADao();
	
	$config = HTMLPurifier_Config::createDefault();
	$config->set('Cache.DefinitionImpl', null);
	$purifier = new HTMLPurifier($config);
	
	$requestId = $purifier->purify($_REQUEST["requestId"]);
	$reference = $purifier->purify($_REQUEST["reference"]);
	$status    = $purifier->purify($_REQUEST["status"]);
	$amount    = $purifier->purify($_REQUEST["amount"]);
	
	$valtot = number_format($amount ,2,'.');
	if ($status == 'APPROVED')
	{	
		$msgerror    = "Tu recarga por un valor de $".$valtot." esta <br>";
		$msgpago     = 'Recibirás una notificación en tu correo registrado.';
		$imagen      = '../images/iconos-07.gif';
		$txtbtn      = 'Regresar';
		$onclick     = "onClick='return fnregresar()'";
		$msgerrorsts = 'Pendiente';
		$fecha       = date('d/m/Y');
		
		/*$dataVal = [
			'externalId'     	=> $reference,
			'statusTransaction' => 'PENDING',
		];
		
		$rsValTrans = $vtaDao->ValTrnPend($dataVal);
		
		if($rsValTrans == 1)
		{
			$data = [
				'transactionId'  	    => $requestId,
				'externalId'     	    => $reference,
				'transferNumber'	    => $requestId,
				'moneyType'	            => 'US',
				'statusTransaction'     => 'APPROVED',
			];
			
			$rsUpdTrans = $vtaDao->UpdateTrnPay($data);
		}
		else
		{*/
			$data = [
				'transactionId'  	=> $requestId,
				'externalId'     	=> $reference,
				'statusTransaction' => 'APPROVED',
				'prepay_error'      => 'OK',
			];
			
			$rsValRec = $vtaDao->ValRecLog($data);
			
			if($rsValRec == 1)
			{
				$msgerrorsts = 'Aprobada';
				$imagen      = '../images/iconos-06.png';
			}
			else
			{
				
				$data = [
					'transactionId'  	=> $requestId,
					'externalId'     	=> $reference,
				];
				
				$rsStatusTrn = $vtaDao->StatusTrn($data);
				if(isset($rsStatusTrn['0']['statusTransaction']))
					$statusTransaction = $rsStatusTrn['0']['statusTransaction'];
				else
					$statusTransaction = '';
				
				if($statusTransaction == "CANCELED")
				{
					//$rev = TrnReverse($id,$token,$urlconf);	
				}
				/*if($statusTransaction == "")
				{
					$urlindex = ReturnIndex();
					header("Location: $urlindex");
				}*/
			}
		//}
	}
	else
	{
		$msgerror = "Tu transacción por un valor de $".$valtot." ha sido <br>";
		$msgpago  = '';
		$imagen   = '../images/iconos-07.png';
		$txtbtn   = 'Regresar';
		$onclick  = "onClick='return fnregresar()'";
		$msgerrorsts = 'Cancelado';//$_REQUEST['tranest'];
		$fecha    = date('d/m/Y');
		
		$data = [
				'transactionId'  	    => $requestId,
				'externalId'     	    => $reference,
				'transferNumber'	    => $requestId,
				'moneyType'	            => 'US',
				'statusTransaction'     => 'REJECTED',
		];
			
		$rsUpdTrans = $vtaDao->UpdateTrnPayRejected($data);
		
		$dataId = [
				'clientTrnId' => $reference,
		];
		
		$rsDelTrans = $vtaDao->DeleteTrnPay($dataId);
	}
}

/*function TrnReverse($transaccion,$token,$url)
{
	//Preparar JSON de llamada para el reverso
	$data_array_r = array("id" => (int)$transaccion);
	
	$data_r = json_encode($data_array_r);
	$curlheader = "Authorization: Bearer " . $token;
	
	//Iniciar Llamada
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $url."Reverse");
	curl_setopt($curl, CURLOPT_POST, 1);
	curl_setopt($curl, CURLOPT_POSTFIELDS, $data_r);
	curl_setopt_array($curl, array(
		CURLOPT_HTTPHEADER => array($curlheader, 'Content-Type:application/json'),
	));
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	$result = curl_exec($curl);
	curl_close($curl);
	
	$data = json_decode($result,true);
	//print_r($data)."<br><br>";
	return $data;
}*/

function ReturnIndex()
{
	$host  = filter_var($_SERVER['HTTP_HOST'],FILTER_SANITIZE_FULL_SPECIAL_CHARS);
	$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	$extra = filter_var('index.php',FILTER_SANITIZE_FULL_SPECIAL_CHARS);
	return "http://$host$uri/$extra";
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0 shrink-to-fit=no">
    <meta name="apple-mobile-web-app-capable" content="yes">

    <!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="../../libs/bootstrap-5.3.3/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/recargas.css">

    <title>RECARGAS CNT</title>
  </head>
  <body>
    <div>
        <?php 
            session_start();
			include('navbar.php');
        ?>
        <div class="row h-auto">
            <div class="col-sm-1"></div>
            <div class="col-sm-10">&nbsp;</div>
            <div class="col-sm-1"></div>
        </div>
        <div class="row h-auto">
            <div class="col-sm-1"></div>
            <div class="col-sm-10 t5"><p class='p7' align="center"><?php echo $msgerror; ?></p></div>
            <div class="col-sm-1"></div>
        </div>
        <div class="row h-auto">
            <div class="col-sm-1"></div>
            <div class="col-sm-10 t8"><p class='p6'><?php echo $msgerrorsts; ?></p></div>
            <div class="col-sm-1"></div>
        </div>
        <div class="row h-auto">
            <div class="col-sm-1 t5"></div>
            <div class="col-sm-10 t5"><p class='p8'><strong>Fecha:</strong> <?php echo $fecha; ?></p></div>
            <div class="col-sm-1"></div>
        </div>
        <div class="row h-auto">
            <div class="col-sm-1"></div>
            <div class="col-sm-10 t5"><p class='p8'><strong>Referencia:</strong> <?php echo $reference; ?></p></div>
            <div class="col-sm-1"></div>
        </div>
        <div class="row h-auto">
            <div class="col-sm-1"></div>
            <div class="col-sm-10 text-center"><img name="iconores" class="img-fluid" width="150" src="<?php echo $imagen;?>" border="0" id="logo_error" alt="Error" /></div>
            <div class="col-sm-1"></div>
        </div>
        <div class="row h-auto">
            <div class="col-sm-1"></div>
            <div class="col-sm-10">&nbsp;</div>
            <div class="col-sm-1"></div>
        </div>
        <div class="row h-auto">
            <div class="col-1"></div>
            <div class="col-10 t2" style='text-align:justify'><p class='p8'><?php echo $msgpago; ?></p></div>
            <div class="col-1"></div>
        </div>
        <div class="row h-auto">
            <div class="col-12 ba"><button class='buttonacc' <?php echo $onclick ?>><?php echo $txtbtn; ?></button></div>
        </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
	<script src="../../libs/bootstrap-5.3.3/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../../libs/jquery/jquery-3.7.1.min.js"></script>
	<script type="text/javascript" src="../js/recargas.js"></script>
	<script>
        function autoRefresh() {
            window.location.reload();
        }
        setInterval('autoRefresh()', 3000);
    </script>
    
  </body>
</html>
