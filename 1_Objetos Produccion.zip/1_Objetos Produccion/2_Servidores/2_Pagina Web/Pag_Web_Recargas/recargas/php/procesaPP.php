<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once('../clases/conscliente.php');
require_once('../servicios/sbopa_param.php');
require_once('../servicios/sbopa_prd.php');
require_once('../../dao/VTADao.php');

$vtaDao = new VTADao();

$numserv = filter_input(INPUT_POST, 'numserv', FILTER_SANITIZE_NUMBER_INT);
$valrec  = filter_input(INPUT_POST, 'recval', FILTER_SANITIZE_NUMBER_INT);
$btnid   = filter_input(INPUT_POST, 'btnid', FILTER_SANITIZE_SPECIAL_CHARS);

$rsPrd     = fnSConsultarBOPA_PRD($btnid,1);
$producttype = $rsPrd->fields[0];
$nametype    = $rsPrd->fields[1];
$packagecode = $rsPrd->fields[2];
$valrec      = $rsPrd->fields[4];
$valrecpp    = $rsPrd->fields[4] * 100;
$branchId    = $rsPrd->fields[11];
$pointsale   = $rsPrd->fields[12];
$storeid     = $rsPrd->fields[14];

$objConscliente = new conscliente($producttype,$numserv,$packagecode);
$dataFact = $objConscliente->getDatos();
$device   = $objConscliente->isMobileDevice();

$oErrorCode     = $dataFact['oErrorCode'];
$oErrorMsg      = $dataFact['oErrorMsg'];
$onombrecliente = $dataFact['onombrecliente'];
$ocedula        = $dataFact['ocedula'];

if($oErrorCode == 0)
{
	$date1 = new DateTime("now", new DateTimeZone('America/Guayaquil') );
	$date2 = new DateTime("now", new DateTimeZone('America/Guayaquil') );
	
	$rsParam   = fnSConsultarBOPA_PARAM('PARAM_ID = 7',1);
	$bankid      = $rsParam->fields[1];
	$login       = $rsParam->fields[5];
	$groupmax    = $rsParam->fields[8];
	$description = $rsParam->fields[9];
	$urldeuna    = $rsParam->fields[16];
	$tiempoexp   = $rsParam->fields[20];
	$iva         = $rsParam->fields[21];
	$token       = $rsParam->fields[19];
	
	$reference  = $description." ".$nametype." ".number_format($valrec,2,'.');
	$groupid    = mt_rand(1, $groupmax);
    $TrnId      = $date1->format('dmyHis').str_pad($groupid, 2, "0", STR_PAD_LEFT);
	$requestId  = 0;
	$status     = 'SUCCESS';
	$processUrl = '';
	
	$minexp = $tiempoexp / 60;
	$date2->modify("+".$minexp." minute");
	
	$valiva  = number_format(($iva * $valrec) / (100 + $iva),2);
	$baseiva = number_format($valrec,2) - $valiva;
	
	$rsMedioBanco = $vtaDao->mediobanco($bankid,$device);
	
	$resPP = array('reference' => $reference,'token' => $token,'clientTransactionId' => $TrnId,'amount' => $valrecpp,'storeid' => $storeid);
	$data = [
			'transactionId'  	    => '0',
			'externalId'     	    => $TrnId,
			'ordererIdentification' => $ocedula,
			'ordererName'			=> $onombrecliente,
			'rechargeType'   		=> $producttype,
			'amount'         		=> $valrec,
			'rechargeDetail' 		=> $reference,
			'branchId' 	        	=> $storeid,
			'pointSale' 	 		=> $storeid,
			'requestDate'    		=> $date1->format('Y-m-d H:i:s'),
			'limitDate'      		=> $date2->format('Y-m-d H:i:s'),
			'serviceNumber'  		=> $numserv,
			'statusAPP'      		=> $status,
			'statusTransaction' 	=> 'PENDING',
			'packageCode'    		=> $packagecode,
			'groupId'        		=> $groupid,
			'attempts'       		=> 0,
			'bankId'         		=> $bankid,
			'meansId'        		=> $rsMedioBanco,
			'deeplink'       		=> $processUrl,
	];
		
	$rsInsTrans = $vtaDao->InsertTrnPay($data);
	if ($rsInsTrans != 1)
	{
		$resPP = [];
	}		
}
else
{
	$resPP = [];
}

$content = array('cliente' => $oErrorCode, 'msgcli' => $oErrorMsg,'device' => $device);
$resultado = array_merge($resPP, $content);

$json = json_encode($resultado);
echo $json;