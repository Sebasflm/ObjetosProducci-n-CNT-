$( document ).ready(function() {
	var tit = '¡RECÁRGATE CON CNT!';
	var msg = 'Elige la categoría de recarga';
	$("#valrec").hide();
	$("#reclista").hide();
	$("#valpre").hide();
	$("#valapl").hide();
	$("#valplus").hide();
	$("#msgreclista").hide();
	$("#txttit").html(tit);
	$("#txtsec").html(msg);
	$("#divregresar").hide();
	
	$("#btnmenu001g").on( "mouseover", function() {
		$('#btnmenu001g').attr('src','../images/btnmenu001a.png');
	} )
	.on( "mouseout", function() {
		$('#btnmenu001g').attr('src','../images/btnmenu001g.png');
	} );
	$("#btnmenu002g").on( "mouseover", function() {
		$('#btnmenu002g').attr('src','../images/btnmenu002a.png');
	} )
	.on( "mouseout", function() {
		$('#btnmenu002g').attr('src','../images/btnmenu002g.png');
	} );
	$("#btnmenu003g").on( "mouseover", function() {
		$('#btnmenu003g').attr('src','../images/btnmenu003a.png');
	} )
	.on( "mouseout", function() {
		$('#btnmenu003g').attr('src','../images/btnmenu003g.png');
	} );
	$("#btnmenu004g").on( "mouseover", function() {
		$('#btnmenu004g').attr('src','../images/btnmenu004a.png');
	} )
	.on( "mouseout", function() {
		$('#btnmenu004g').attr('src','../images/btnmenu004g.png');
	} );
	
	$("#btnsaldo3g").on( "mouseover", function() {
		$('#btnsaldo3g').attr('src','../images/btnsaldo3a.png');
	} )
	.on( "mouseout", function() {
		$('#btnsaldo3g').attr('src','../images/btnsaldo3g.png');
	} );
	
	$("#btnsaldo5g").on( "mouseover", function() {
		$('#btnsaldo5g').attr('src','../images/btnsaldo5a.png');
	} )
	.on( "mouseout", function() {
		$('#btnsaldo5g').attr('src','../images/btnsaldo5g.png');
	} );
	
	$("#btnsaldo6g").on( "mouseover", function() {
		$('#btnsaldo6g').attr('src','../images/btnsaldo6a.png');
	} )
	.on( "mouseout", function() {
		$('#btnsaldo6g').attr('src','../images/btnsaldo6g.png');
	} );
	
	$("#btnsaldo10g").on( "mouseover", function() {
		$('#btnsaldo10g').attr('src','../images/btnsaldo10a.png');
	} )
	.on( "mouseout", function() {
		$('#btnsaldo10g').attr('src','../images/btnsaldo10g.png');
	} );
	
	$("#btnsaldo15g").on( "mouseover", function() {
		$('#btnsaldo15g').attr('src','../images/btnsaldo15a.png');
	} )
	.on( "mouseout", function() {
		$('#btnsaldo15g').attr('src','../images/btnsaldo15g.png');
	} );
	
	$("#btnsaldo20g").on( "mouseover", function() {
		$('#btnsaldo20g').attr('src','../images/btnsaldo20a.png');
	} )
	.on( "mouseout", function() {
		$('#btnsaldo20g').attr('src','../images/btnsaldo20g.png');
	} );
	
	$("#btncontinuarg").on( "mouseover", function() {
		$('#btncontinuarg').attr('src','../images/btncontinuara.png');
	} )
	.on( "mouseout", function() {
		$('#btncontinuarg').attr('src','../images/btncontinuarg.png');
	} );
	
	$("#btncontinuarpg").on( "mouseover", function() {
		$('#btncontinuarpg').attr('src','../images/btncontinuarpa.png');
	} )
	.on( "mouseout", function() {
		$('#btncontinuarpg').attr('src','../images/btncontinuarpg.png');
	} );
	
	$("#btncontinuarag").on( "mouseover", function() {
		$('#btncontinuarag').attr('src','../images/btncontinuaraa.png');
	} )
	.on( "mouseout", function() {
		$('#btncontinuarag').attr('src','../images/btncontinuarag.png');
	} );
	
	$("#btncontinuarplg").on( "mouseover", function() {
		$('#btncontinuarplg').attr('src','../images/btncontinuarpla.png');
	} )
	.on( "mouseout", function() {
		$('#btncontinuarplg').attr('src','../images/btncontinuarplg.png');
	} );
	
	$("#btnprepago1g").on( "mouseover", function() {
		$('#btnprepago1g').attr('src','../images/btnprepago1a.png');
	} )
	.on( "mouseout", function() {
		$('#btnprepago1g').attr('src','../images/btnprepago1g.png');
	} );
	
	$("#btnprepago2g").on( "mouseover", function() {
		$('#btnprepago2g').attr('src','../images/btnprepago2a.png');
	} )
	.on( "mouseout", function() {
		$('#btnprepago2g').attr('src','../images/btnprepago2g.png');
	} );
	
	$("#btnprepago3g").on( "mouseover", function() {
		$('#btnprepago3g').attr('src','../images/btnprepago3a.png');
	} )
	.on( "mouseout", function() {
		$('#btnprepago3g').attr('src','../images/btnprepago3g.png');
	} );
	
	$("#btnprepago5g").on( "mouseover", function() {
		$('#btnprepago5g').attr('src','../images/btnprepago5a.png');
	} )
	.on( "mouseout", function() {
		$('#btnprepago5g').attr('src','../images/btnprepago5g.png');
	} );
	
	$("#btnprepago6g").on( "mouseover", function() {
		$('#btnprepago6g').attr('src','../images/btnprepago6a.png');
	} )
	.on( "mouseout", function() {
		$('#btnprepago6g').attr('src','../images/btnprepago6g.png');
	} );
	
	$("#btnprepago10g").on( "mouseover", function() {
		$('#btnprepago10g').attr('src','../images/btnprepago10a.png');
	} )
	.on( "mouseout", function() {
		$('#btnprepago10g').attr('src','../images/btnprepago10g.png');
	} );
	
	$("#btnprepago15g").on( "mouseover", function() {
		$('#btnprepago15g').attr('src','../images/btnprepago15a.png');
	} )
	.on( "mouseout", function() {
		$('#btnprepago15g').attr('src','../images/btnprepago15g.png');
	} );
	
	$("#btnprepago20g").on( "mouseover", function() {
		$('#btnprepago20g').attr('src','../images/btnprepago20a.png');
	} )
	.on( "mouseout", function() {
		$('#btnprepago20g').attr('src','../images/btnprepago20g.png');
	} );
	
	$("#btnprepagoi3g").on( "mouseover", function() {
		$('#btnprepagoi3g').attr('src','../images/btnprepagoi3a.png');
	} )
	.on( "mouseout", function() {
		$('#btnprepagoi3g').attr('src','../images/btnprepagoi3g.png');
	} );
	
	$("#logo_netflix").on( "mouseover", function() {
		$('#logo_netflix').attr('src','../images/logo_netflix_p.png');
	} )
	.on( "mouseout", function() {
		$('#logo_netflix').attr('src','../images/logo_netflix.png');
	} );	
	
	$("#logo_instagram").on( "mouseover", function() {
		$('#logo_instagram').attr('src','../images/logo_instagram_p.png');
	} )
	.on( "mouseout", function() {
		$('#logo_instagram').attr('src','../images/logo_instagram.png');
	} );
	
	$("#logo_spotify").on( "mouseover", function() {
		$('#logo_spotify').attr('src','../images/logo_spotify_p.png');
	} )
	.on( "mouseout", function() {
		$('#logo_spotify').attr('src','../images/logo_spotify.png');
	} );
	
	$("#logo_tiktok").on( "mouseover", function() {
		$('#logo_tiktok').attr('src','../images/logo_tiktok_p.png');
	} )
	.on( "mouseout", function() {
		$('#logo_tiktok').attr('src','../images/logo_tiktok.png');
	} );
	
	$("#logo_waze").on( "mouseover", function() {
		$('#logo_waze').attr('src','../images/logo_waze_p.png');
	} )
	.on( "mouseout", function() {
		$('#logo_waze').attr('src','../images/logo_waze.png');
	} );
	
	$("#logo_google").on( "mouseover", function() {
		$('#logo_google').attr('src','../images/logo_google_p.png');
	} )
	.on( "mouseout", function() {
		$('#logo_google').attr('src','../images/logo_google.png');
	} );
	
	$("#paqueteplus10g").on( "mouseover", function() {
		$('#paqueteplus10g').attr('src','../images/paqueteplus10a.png');
	} )
	.on( "mouseout", function() {
		$('#paqueteplus10g').attr('src','../images/paqueteplus10g.png');
	} );
	
	$("#paqueteplus20g").on( "mouseover", function() {
		$('#paqueteplus20g').attr('src','../images/paqueteplus20a.png');
	} )
	.on( "mouseout", function() {
		$('#paqueteplus20g').attr('src','../images/paqueteplus20g.png');
	} );
	
	$( "#btnprepago1g" ).on( "click", function() {
		$('#paqueteprepago').attr('src','../images/paquete1.png');
	});
	
	$( "#btnprepago2g" ).on( "click", function() {
		$('#paqueteprepago').attr('src','../images/paquete2.png');
		$('#btnprepago1g').attr('src','../images/btnprepago1g.png');
	});
	
	$( "#btnprepago3g" ).on( "click", function() {
		$('#paqueteprepago').attr('src','../images/paquete3.png');
		$('#btnprepago1g').attr('src','../images/btnprepago1g.png');
	});
	
	$( "#btnprepago5g" ).on( "click", function() {
		$('#paqueteprepago').attr('src','../images/paquete5.png');
		$('#btnprepago1g').attr('src','../images/btnprepago1g.png');
	});
	
	$( "#btnprepago6g" ).on( "click", function() {
		$('#paqueteprepago').attr('src','../images/paquete6.png');
		$('#btnprepago1g').attr('src','../images/btnprepago1g.png');
	});
	
	$( "#btnprepago10g" ).on( "click", function() {
		$('#paqueteprepago').attr('src','../images/paquete10.png');
		$('#btnprepago1g').attr('src','../images/btnprepago1g.png');
	});
	
	$( "#btnprepago15g" ).on( "click", function() {
		$('#paqueteprepago').attr('src','../images/paquete15.png');
		$('#btnprepago1g').attr('src','../images/btnprepago1g.png');
	});
	
	$( "#btnprepago20g" ).on( "click", function() {
		$('#paqueteprepago').attr('src','../images/paquete20.png');
		$('#btnprepago1g').attr('src','../images/btnprepago1g.png');
	});
	
	$( "#btnprepagoi3g" ).on( "click", function() {
		$('#paqueteprepago').attr('src','../images/paquetei3.png');
		$('#btnprepago1g').attr('src','../images/btnprepago1g.png');
	});
	
	$( "#logo_netflix" ).on( "click", function() {
		$('#paqueteaplicacion').attr('src','../images/appnetflix.png');
		$('#logo_netflix').attr('src','../images/logo_netflix.png');
	});
	$( "#logo_instagram" ).on( "click", function() {
		$('#paqueteaplicacion').attr('src','../images/appinstagram.png');
		$('#logo_netflix').attr('src','../images/logo_netflix.png');
	});
	$( "#logo_spotify" ).on( "click", function() {
		$('#paqueteaplicacion').attr('src','../images/appspotify.png');
		$('#logo_netflix').attr('src','../images/logo_netflix.png');
	});
	$( "#logo_tiktok" ).on( "click", function() {
		$('#paqueteaplicacion').attr('src','../images/apptiktok.png');
		$('#logo_netflix').attr('src','../images/logo_netflix.png');
	});
	$( "#logo_waze" ).on( "click", function() {
		$('#paqueteaplicacion').attr('src','../images/appwaze.png');
		$('#logo_netflix').attr('src','../images/logo_netflix.png');
	});
	$( "#logo_google" ).on( "click", function() {
		$('#paqueteaplicacion').attr('src','../images/appgoogle.png');
		$('#logo_netflix').attr('src','../images/logo_netflix.png');
	});
	$( "#paqueteplus10g" ).on( "click", function() {
		$('#paqueteplus').attr('src','../images/paqplus10.png');
		$('#paqueteplus10g').attr('src','../images/paqueteplus10g.png');
	});
	$( "#paqueteplus20g" ).on( "click", function() {
		$('#paqueteplus').attr('src','../images/paqplus20.png');
		$('#paqueteplus10g').attr('src','../images/paqueteplus10g.png');
	});
	
});

$('#numserv').on('input', function () { 
    this.value = this.value.replace(/[^0-9]/g,'');
});

function getbtnval(valrec,id)
{
	$("input[type=hidden][name=recarga]").val(valrec);
	$("input[type=hidden][name=btnid]").val(id);
}

function getbtnvalp(valrec,id)
{
	$("input[type=hidden][name=recargap]").val(valrec);
	$("input[type=hidden][name=btnidp]").val(id);
}

function getbtnvala(valrec,id)
{
	$("input[type=hidden][name=recargaa]").val(valrec);
	$("input[type=hidden][name=btnida]").val(id);
}

function getbtnvalpl(valrec,id)
{
	$("input[type=hidden][name=recargapl]").val(valrec);
	$("input[type=hidden][name=btnidpl]").val(id);
}

function recSaldo()
{
	$("#catrec").hide();
	$("#valpre").hide();
	$("#valapl").hide();
	$("#valplus").hide();
	$("#reclista").hide();
	$("#msgreclista").hide();
	msg = 'Elige el valor de tu recarga prepago';
	tit = '¡RECÁRGATE CON CNT!';
	$("#txtsec").html(msg);
	$("#valrec").show("slow");
	$('#valrec').removeClass('hidden');
	$("#msgrec").show();
	$("#txttit").html(tit);
	document.getElementById("frmrec").reset();
	$("#divregresar").show();
}

function recPrepago()
{
	$("#catrec").hide();
	$("#valrec").hide();
	$("#valapl").hide();
	$("#valplus").hide();
	$("#reclista").hide();
	$("#msgreclista").hide();
	msg = 'Elige el paquete prepago que más se adapte a ti';
	tit = '¡RECÁRGATE CON CNT!';
	$("#txtsec").html(msg);
	$("#valpre").show("slow");
	$('#valpre').removeClass('hidden');
	$("#msgrec").show();
	$("#txttit").html(tit);
	document.getElementById("frmpre").reset();
	$("#divregresar").show();
	
	$('[id="btnprepago1"]').attr('checked',true);
	$('#btnprepago1g').attr('src','../images/btnprepago1a.png');
	$("input[type=hidden][name=recargap]").val(1);
	$("input[type=hidden][name=btnidp]").val("btnprepago1");
}

function recAplica()
{
	$("#catrec").hide();
	$("#valrec").hide();
	$("#valpre").hide();
	$("#valplus").hide();
	$("#reclista").hide();
	$("#msgreclista").hide();
	msg = 'Elige el paquete de aplicación que desees recargar';
	tit = '¡RECÁRGATE CON CNT!';
	$("#txtsec").html(msg);
	$("#valapl").show("slow");
	$('#valapl').removeClass('hidden');
	$("#msgrec").show();
	$("#txttit").html(tit);
	document.getElementById("frmapl").reset();
	$("#divregresar").show();
	
	$('[id="paq_netflix"]').attr('checked',true);
	$('#logo_netflix').attr('src','../images/logo_netflix_p.png');
	$("input[type=hidden][name=recargaa]").val(1);
	$("input[type=hidden][name=btnida]").val("paq_netlix");
}

function recPlus()
{
	$("#catrec").hide();
	$("#valrec").hide();
	$("#valpre").hide();
	$("#valapl").hide();
	$("#reclista").hide();
	$("#msgreclista").hide();
	msg = 'Elige el paquete de plus que desees recargar';
	tit = '¡RECÁRGATE CON CNT!';
	$("#txtsec").html(msg);
	$("#valplus").show("slow");
	$('#valplus').removeClass('hidden');
	$("#msgrec").show();
	$("#txttit").html(tit);
	document.getElementById("frmplus").reset();
	$("#divregresar").show();
	
	$('[id="paqueteplus10"]').attr('checked',true);
	$('#paqueteplus10g').attr('src','../images/paqueteplus10a.png');
	$("input[type=hidden][name=recargapl]").val(10);
	$("input[type=hidden][name=btnidpl]").val("paqueteplus10");
}

function fnPagoDeUna(opcion){
	if(opcion == 1)
	{
		var numserv = $("#numserv").val();
		var recarga  = $("#recarga").val();
		var btnid  = $("#btnid").val();
		//var detail = 'RECARGA DINERO';
		var m = '';
	}
	if(opcion == 2)
	{
		var numserv = $("#numservp").val();
		var recarga  = $("#recargap").val();
		var btnid  = $("#btnidp").val();
		//var detail = 'PAQUETE PREPAGO';
		var m = 'p';
	}
	if(opcion == 3)
	{
		var numserv = $("#numserva").val();
		var recarga  = $("#recargaa").val();
		var btnid  = $("#btnida").val();
		//var detail = 'PAQUETE APLICACIONES';
		var m = 'a';
	}
	if(opcion == 4)
	{
		var numserv = $("#numservpl").val();
		var recarga  = $("#recargapl").val();
		var btnid  = $("#btnidpl").val();
		//var detail = 'PAQUETE PLUS';
		var m = 'pl';
	}
	let sw = 0;
	
	if(numserv == '')
	{
		$("#msgvalserv" + m).html("Ingresa un número de celular");
		sw = 1;
    }
	else
	{
		if(numserv.length < 10)
        {
            $("#msgvalserv" + m).html("El número ingresado no cumple con el total de dígitos");
            sw = 1;
        }
		else
		{	
			if(recarga == '0')
			{
				$("#msgvalserv" + m).html("Selecciona el valor de tu recarga");
				sw = 1;
			}
			else
			{
				const numserv0 = numserv.slice(1)
				
				$.ajax({
					async: false,
					cache: false,
					url: "procesaDeUna.php",
					type: "POST",
					data: { numserv: numserv0, recval: recarga, btnid: btnid},
					dataType : 'json',
					success: function(data) 
					{	
						if(data.cliente != 0)
						{
							sw = 1;
							$("#msgvalserv" + m).html(data.msgcli);
						}
						else
						{
							$("#valrec").hide();
							$("#valpre").hide();
							$("#msgrec").hide();
							$("#valapl").hide();
							$("#valplus").hide();
							$("#msgreclista").show("slow");
							
							if(data.device == 'WEB')
							{
								$("#reclista").show("slow");	
								msgt = '¡Tu recarga está casi lista!';
								msg  = 'Escanea el código QR con tu celular y<br>paga con la aplicación <br><img id="logodeuna" src="../images/btn_deuna.png" width="100" alt="DE UNA"/>';
								$("#txttit").html(msgt);
								$("#txtrec").html(msg);
								document.getElementById("deunaqr").src = data.qr;	
							}
							else
							{
								msg = '';
								$("#msgvalserv" + m).html("");
								window.location.href = data.deeplink;
							}
							$("#txtsec").html(msg);
						}
					}
				})
			}
		}
	}
	if(sw == 1)
    {	
        return false;
    }
}

function fnPagoPtoP(opcion){
	if(opcion == 1)
	{
		var numserv = $("#numserv").val();
		var recarga  = $("#recarga").val();
		var btnid  = $("#btnid").val();
		var m = '';
	}
	if(opcion == 2)
	{
		var numserv = $("#numservp").val();
		var recarga  = $("#recargap").val();
		var btnid  = $("#btnidp").val();
		var m = 'p';
	}
	if(opcion == 3)
	{
		var numserv = $("#numserva").val();
		var recarga  = $("#recargaa").val();
		var btnid  = $("#btnida").val();
		var m = 'a';
	}
	if(opcion == 4)
	{
		var numserv = $("#numservpl").val();
		var recarga  = $("#recargapl").val();
		var btnid  = $("#btnidpl").val();
		var m = 'pl';
	}
	let sw = 0;
	
	if(numserv == '')
	{
		$("#msgvalserv" + m).html("Ingresa un número de celular");
		sw = 1;
    }
	else
	{
		if(numserv.length < 10)
        {
            $("#msgvalserv" + m).html("El número ingresado no cumple con el total de dígitos");
            sw = 1;
        }
		else
		{	
			if(recarga == '0')
			{
				$("#msgvalserv" + m).html("Selecciona el valor de tu recarga");
				sw = 1;
			}
			else
			{
				const numserv0 = numserv.slice(1)
				document.getElementById("amountrec").value = recarga;
				$.ajax({
					async: false,
					cache: false,
					url: "procesaPtoP.php",
					type: "POST",
					data: { numserv: numserv0, recval: recarga, btnid: btnid},
					dataType : 'json',
					success: function(data) 
					{
						if(data.cliente == 0)
						{
							$("#msgvalserv" + m).html("");
							var processUrl = data.processUrl;
							P.init(processUrl);
						}
						else
						{
							sw = 1;
							$("#msgvalserv" + m).html(data.msgcli);
						}
					}
				})
			}
		}
	}
	if(sw == 1)
    {	
        return false;
    }
}

function fnPagoPP(opcion){
	if(opcion == 1)
	{
		var numserv = $("#numserv").val();
		var recarga  = $("#recarga").val();
		var btnid  = $("#btnid").val();
		var m = '';
	}
	if(opcion == 2)
	{
		var numserv = $("#numservp").val();
		var recarga  = $("#recargap").val();
		var btnid  = $("#btnidp").val();
		var m = 'p';
	}
	if(opcion == 3)
	{
		var numserv = $("#numserva").val();
		var recarga  = $("#recargaa").val();
		var btnid  = $("#btnida").val();
		var m = 'a';
	}
	if(opcion == 4)
	{
		var numserv = $("#numservpl").val();
		var recarga  = $("#recargapl").val();
		var btnid  = $("#btnidpl").val();
		var m = 'pl';
	}
	let sw = 0;
	
	if(numserv == '')
	{
		$("#msgvalserv" + m).html("Ingresa un número de celular");
		sw = 1;
    }
	else
	{
		if(numserv.length < 10)
        {
            $("#msgvalserv" + m).html("El número ingresado no cumple con el total de dígitos");
            sw = 1;
        }
		else
		{	
			if(recarga == '0')
			{
				$("#msgvalserv" + m).html("Selecciona el valor de tu recarga");
				sw = 1;
			}
			else
			{
				const numserv0 = numserv.slice(1)
				$.ajax({
					async: false,
					cache: false,
					url: "procesaPP.php",
					type: "POST",
					data: { numserv: numserv0, recval: recarga, btnid: btnid},
					dataType : 'json',
					success: function(data) 
					{
						if(data.cliente == 0)
						{
							$("#modalPP").modal('show');
							document.getElementById("clientTrnId").value = data.clientTransactionId;
							
							ppb = new PPaymentButtonBox({
								token: data.token,
								amount: data.amount, // monto total de venta
								amountWithoutTax: data.amount,
								storeId: data.storeid,
								reference: data.reference, //Referencia de pago
								clientTransactionId: data.clientTransactionId, ////id unico. debe cambiar para cada transaccion
							}).render('pp-button');
						}
						else
						{
							sw = 1;
							$("#msgvalserv" + m).html(data.msgcli);
						}
					}
				})	
			}
		}
	}
	if(sw == 1)
    {	
        return false;
    }
}

function fnContinuarRec()
{
	if(document.getElementById("chkAceptoRec").checked)
    {
		//document.getElementById("btndeunarec").disabled = false;
		document.getElementById("btnpprec").disabled 	= false;
		document.getElementById("btnptoprec").disabled 	= false;
		//$('#btndeunarec').removeClass('imagebtn');
		$('#btnpprec').removeClass('imagebtn');
		$('#btnptoprec').removeClass('imagebtn');
	}
	else
	{
		//document.getElementById("btndeunarec").disabled = true;
		document.getElementById("btnpprec").disabled 	= true;
		document.getElementById("btnptoprec").disabled 	= true;
		//$('#btndeunarec').addClass('imagebtn');
		$('#btnpprec').addClass('imagebtn');
		$('#btnptoprec').addClass('imagebtn');
	}
}

function fnContinuarPre()
{
	if(document.getElementById("chkAceptoPre").checked)
    {
		//document.getElementById("btndeunapre").disabled = false;
		document.getElementById("btnpppre").disabled 	= false;
		document.getElementById("btnptoppre").disabled 	= false;
		//$('#btndeunapre').removeClass('imagebtn');
		$('#btnpppre').removeClass('imagebtn');
		$('#btnptoppre').removeClass('imagebtn');
	}
	else
	{
		//document.getElementById("btndeunapre").disabled = true;
		document.getElementById("btnpppre").disabled 	= true;
		document.getElementById("btnptoppre").disabled 	= true;
		//$('#btndeunapre').addClass('imagebtn');
		$('#btnpppre').addClass('imagebtn');
		$('#btnptoppre').addClass('imagebtn');
	}
}

function fnContinuarApl()
{
	if(document.getElementById("chkAceptoApl").checked)
    {
		//document.getElementById("btndeunaapl").disabled = false;
		document.getElementById("btnppapl").disabled 	= false;
		document.getElementById("btnptopapl").disabled 	= false;
		//$('#btndeunaapl').removeClass('imagebtn');
		$('#btnppapl').removeClass('imagebtn');
		$('#btnptopapl').removeClass('imagebtn');
	}
	else
	{
		//document.getElementById("btndeunaapl").disabled = true;
		document.getElementById("btnppapl").disabled 	= true;
		document.getElementById("btnptopapl").disabled 	= true;
		//$('#btndeunaapl').addClass('imagebtn');
		$('#btnppapl').addClass('imagebtn');
		$('#btnptopapl').addClass('imagebtn');
	}
}

function fnContinuarPlus()
{
	if(document.getElementById("chkAceptoPlus").checked)
    {
		//document.getElementById("btndeunaplus").disabled = false;
		document.getElementById("btnppplus").disabled 	 = false;
		document.getElementById("btnptopplus").disabled  = false;
		//$('#btndeunaplus').removeClass('imagebtn');
		$('#btnppplus').removeClass('imagebtn');
		$('#btnptopplus').removeClass('imagebtn');
	}
	else
	{
		//document.getElementById("btndeunaplus").disabled = true;
		document.getElementById("btnppplus").disabled 	 = true;
		document.getElementById("btnptopplus").disabled  = true;
		//$('#btndeunaplus').addClass('imagebtn');
		$('#btnppplus').addClass('imagebtn');
		$('#btnptopplus').addClass('imagebtn');
	}
}

function fnregresar(){
    window.location.href = "index.php";
}

$('#modalPP').on('hidden.bs.modal', function () {
	var clientTrnId = $("#clientTrnId").val();
	$.ajax({
		async: false,
		cache: false,
		url: "cancelaPP.php",
		type: "POST",
		data: { clientTrnId: clientTrnId},
		dataType : 'json',
		success: function(data) 
		{
			if(data.delTrans == 1)
			{
				alert("Transacción cancelada");
				window.location.href = 'index.php';
			}
		}
	})
})