$( document ).ready(function() {
	var tit = 'Historial de Recárgas';
	$("#txttit").html(tit);
});

$('#numserv').on('input', function () { 
    this.value = this.value.replace(/[^0-9]/g,'');
});