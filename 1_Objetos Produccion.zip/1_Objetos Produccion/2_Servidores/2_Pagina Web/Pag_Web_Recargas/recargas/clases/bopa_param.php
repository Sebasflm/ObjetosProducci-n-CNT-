<?php
//Se incluye el archivo de la conexion a la base de datos
require_once('../../libs/conexion/connConci.php');

//------------------------------------------------------------------------------------------------------------------------
//  PROYECTO: BOTON DE PAGOS PLACE TO PAY
//  CLIENTE:  CNT EP
//  DESARROLLADO POR:  CNT EP
//  AUTOR:  Fabian Villavicencio Paez
//  EMAIL:  fabiane.villavicencio@cnt.gob.ec
//  WEBSITE:  http://www.cnt.gob.ec

//  TITULO:  config.con.php.php
//  DESCRIPCION:  Permite consultar el valor a pagar
//  FECHA DE CREACION:  22-10-2019
//  --------------------------------------------------------------------------------------------------------
//  MODIFICACIONES:
//     FECHA            AUTOR           		DESCRIPCION

class BOPA_PARAM
{
  // ATRIBUTOS

  var $PARAM_ID;	    //NUMBER	No		1	id
  var $PARAM_BCOOP;	//NUMBER	Yes		2	Banco OPEN
  var $PARAM_SUCOP;	//NUMBER	Yes		3	Sucursal OPEN
  var $PARAM_BCOSM;	//NUMBER	Yes		4	"Banco SMART"
  var $PARAM_SUCSM;	//NUMBER	Yes		5	Sucursal SMART
  var $PARAM_LOGIN;	//VARCHAR2(40 BYTE)	Yes		6	Login estrucutra autorizacion PtP
  var $PARAM_SECRET;	//VARCHAR2(40 BYTE)	Yes		7	Secret Key estructura autorizacion PtP
  var $PARAM_TRNIDOP;	//NUMBER	Yes		8	Ultimo Id Transaccion OPEN
  var $PARAM_TRNIDSM;	//NUMBER	Yes		9	Ultimo Id Transaccion SMART
  var $PARAM_DESCPP;	//VARCHAR2(80 BYTE)	Yes		10	Descripcion CreateRequest PtP
  var $PARAM_URLRET;	//VARCHAR2(80 BYTE)	Yes		11	URL Retorno CreateRequest PtP
  var $PARAM_ISBUSER;	//VARCHAR2(40 BYTE)	Yes		12	Usuario para registrar el pago
  var $PARAM_ISBTERM;	//VARCHAR2(40 BYTE)	No		13	Terminal para registrar el pago
  var $PARAM_PAYMETH;	//VARCHAR2(10 BYTE)	Yes		14	Metodo de pago para registrar el pago
  var $PARAM_MONTIP;	//VARCHAR2(10 BYTE)	No		15	Tipo de Moneda para registrar el pago
  var $PARAM_COMME;	//VARCHAR2(40 BYTE)	Yes		16	Comentarios para registrar el pago
  var $PARAM_URLPTP;	//VARCHAR2(80 BYTE)	Yes		17	URL DE APIS DE PtoP
  var $PARAM_LOGIN_SM;	//VARCHAR2(40 BYTE)	Yes		6	Login estrucutra autorizacion PtP Movil
  var $PARAM_SECRET_SM;	//VARCHAR2(40 BYTE)	Yes		7	Secret Key estructura autorizacion PtP Movil

  function fnConsultarBOPA_PARAM($strParametroBusqueda,$srtTipoBusqueda)
  {
	  global $cnnOracle;
	  $cnnOracle = connConci();
	  switch($srtTipoBusqueda)
	  {
            case 1:   $strSql = "SELECT PARAM_ID,PARAM_BCOOP,PARAM_SUCOP,PARAM_BCOSM,PARAM_SUCSM,PARAM_LOGIN,
                                        PARAM_SECRET,PARAM_TRNIDOP,PARAM_TRNIDSM,PARAM_DESCPP,PARAM_URLRET,
                                        PARAM_ISBUSER,PARAM_ISBTERM,PARAM_PAYMETH,PARAM_MONTIP,PARAM_COMME,PARAM_URLPTP,
										PARAM_LOGIN_SM,PARAM_SECRET_SM,PARAM_TOKEN_PP,PARAM_EXPTIME,PARAM_IVA
            				            FROM BOPAPP_PARAM
										WHERE $strParametroBusqueda";
			break;
       }
      //echo $strSql;
      $rsBOPA_PARAM=$cnnOracle->Execute($strSql);
	  //$cnnOracle->Close();
      return ($rsBOPA_PARAM) ? $rsBOPA_PARAM : 0;
  }
}

?>