<?php
//Se incluye el archivo de la conexion a la base de datos
require_once('../../libs/conexion/connConci.php');

//------------------------------------------------------------------------------------------------------------------------
//  PROYECTO: BOTON DE PAGOS PLACE TO PAY
//  CLIENTE:  CNT EP
//  DESARROLLADO POR:  CNT EP
//  AUTOR:  Fabian Villavicencio Paez
//  EMAIL:  fabiane.villavicencio@cnt.gob.ec
//  WEBSITE:  http://www.cnt.gob.ec

//  TITULO:  config.con.php.php
//  DESCRIPCION:  Permite consultar el valor a pagar
//  FECHA DE CREACION:  22-10-2019
//  --------------------------------------------------------------------------------------------------------
//  MODIFICACIONES:
//     FECHA            AUTOR           		DESCRIPCION

class BOPA_PRD
{
  function fnConsultarBOPA_PRD($strParametroBusqueda,$srtTipoBusqueda)
  {
	  global $cnnOracle;
	  $cnnOracle = connConci();
	  switch($srtTipoBusqueda)
	  {
            case 1:   $strSql = "select producttype, nametype, packagecode, packagename, valuepackage, pathimage, 
								 productstatus, creationdate, retiredate, user_prd, frame, branchid, pointsale, id_prd, storeid, login, secret
								 from bopa_prd_mng_recharge
								 where frame =  '".$strParametroBusqueda."'";
			break;
       }
      //echo $strSql;
      $rsBOPA_PARAM=$cnnOracle->Execute($strSql);
	  //$cnnOracle->Close();
      return ($rsBOPA_PARAM) ? $rsBOPA_PARAM : 0;
  }
}

?>