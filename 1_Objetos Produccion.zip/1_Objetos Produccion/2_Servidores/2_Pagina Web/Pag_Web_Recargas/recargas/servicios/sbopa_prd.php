<?php 
require_once('../clases/bopa_prd.php'); 

//------------------------------------------------------------------------------------------------------------------------
//  PROYECTO: BOTON DE PAGOS PLACE TO PAY
//  CLIENTE:  CNT EP
//  DESARROLLADO POR:  CNT EP
//  AUTOR:  Fabian Villavicencio Paez
//  EMAIL:  fabiane.villavicencio@cnt.gob.ec
//  WEBSITE:  http://www.cnt.gob.ec

//  TITULO:  config.con.php.php
//  DESCRIPCION:  Permite consultar el valor a pagar
//  FECHA DE CREACION:  22-10-2019
//  --------------------------------------------------------------------------------------------------------
//  MODIFICACIONES:
//     FECHA            AUTOR           		DESCRIPCION
  
  function fnSConsultarBOPA_PRD($strParametroBusqueda,$srtTipoBusqueda)
  {	
	  $objBOPA_PRD = new BOPA_PRD();
      $rsBOPA_PRD = $objBOPA_PRD->fnConsultarBOPA_PRD($strParametroBusqueda,$srtTipoBusqueda);
      return $rsBOPA_PRD;  
  }
// FIN
?>